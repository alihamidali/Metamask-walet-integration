import { Routes } from '@angular/router';

export const routes: Routes = [
    {
        path: '',
        loadChildren: async () => (await import('@pages/home')).routes,
    },
    {
        path: 'users/:username',
        loadChildren: async () => (await import('@pages/user')).routes,
    },
    {
        path: 'settings',
        loadChildren: async () => (await import('@pages/settings')).routes,
    },
    {
        path: '**',
        loadComponent: async () => (await import('@pages/screens/not-found/not-found.component')).NotFoundComponent,
    },
];
