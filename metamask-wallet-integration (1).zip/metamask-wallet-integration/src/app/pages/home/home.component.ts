import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, inject, OnDestroy, OnInit } from '@angular/core';
import { RouterModule } from '@angular/router';
import { AppTheme, ThemeService } from '@lib/services/theme';
import { NetworkInfo, Web3Service } from '@lib/services/web3';
import { Subject, takeUntil } from 'rxjs';

@Component({
    standalone: true,
    imports: [CommonModule, RouterModule],
    templateUrl: './home.component.html',
})
export class HomeComponent implements OnInit, OnDestroy {
    currentTheme!: AppTheme | null;
    walletAddress: string | null = null;
    networkInfo: NetworkInfo | null = null;
    isMetaMaskInstalled = false;
    errorMessage: string | null = null;

    private readonly _themeService = inject(ThemeService);
    private readonly _web3Service = inject(Web3Service);
    private readonly _cdr = inject(ChangeDetectorRef);

    private readonly _destroy$ = new Subject();

    ngOnInit(): void {
        this._themeService.currentTheme$.pipe(takeUntil(this._destroy$)).subscribe((theme) => {
            this.currentTheme = theme;
            this._cdr.markForCheck();
        });

        this._web3Service.walletAddress$.pipe(takeUntil(this._destroy$)).subscribe((address) => {
            console.log('Wallet address updated in component:', address);
            this.walletAddress = address;
            this._cdr.markForCheck();
        });

        this._web3Service.networkInfo$.pipe(takeUntil(this._destroy$)).subscribe((network) => {
            console.log('Network info updated in component:', network);
            this.networkInfo = network;
            this._cdr.markForCheck();
        });

        this._web3Service.isMetaMaskInstalled$.pipe(takeUntil(this._destroy$)).subscribe((installed) => {
            this.isMetaMaskInstalled = installed;
            this._cdr.markForCheck();
        });

        this._web3Service.errorMessage$.pipe(takeUntil(this._destroy$)).subscribe((error) => {
            this.errorMessage = error;
            this._cdr.markForCheck();
        });
    }

    ngOnDestroy(): void {
        this._destroy$.complete();
        this._destroy$.unsubscribe();
    }

    handleThemeChange(theme: AppTheme): void {
        this._themeService.setTheme(theme);
    }

    async connectWallet(): Promise<void> {
        await this._web3Service.connectWallet();
    }

    disconnectWallet(): void {
        this._web3Service.disconnectWallet();
    }

    getShortenedAddress(): string {
        return this._web3Service.shortenAddress(this.walletAddress);
    }
}
