import { TestBed } from '@angular/core/testing';
import { Web3Service } from './web3.service';

describe('Web3Service', () => {
    let service: Web3Service;

    beforeEach(() => {
        TestBed.configureTestingModule({});
        service = TestBed.inject(Web3Service);
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('should shorten address correctly', () => {
        const address = '0x1234567890123456789012345678901234567890';
        const shortened = service.shortenAddress(address);
        expect(shortened).toBe('0x1234...7890');
    });

    it('should return empty string for null address', () => {
        const shortened = service.shortenAddress(null);
        expect(shortened).toBe('');
    });
});