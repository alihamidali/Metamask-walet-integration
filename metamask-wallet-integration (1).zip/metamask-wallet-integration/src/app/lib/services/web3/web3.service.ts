import { Injectable, NgZone } from '@angular/core';
import { BrowserProvider, Eip1193Provider } from 'ethers';
import { BehaviorSubject } from 'rxjs';

declare global {
    interface Window {
        ethereum?: Eip1193Provider & {
            isMetaMask?: boolean;
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            on?: (event: string, callback: (...args: any[]) => void) => void;
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            removeListener?: (event: string, callback: (...args: any[]) => void) => void;
        };
    }
}

export interface NetworkInfo {
    chainId: string;
    name: string;
    isSupported: boolean;
}

interface MetaMaskError {
    code: number;
    message: string;
}

/* eslint-disable @typescript-eslint/naming-convention */
const SUPPORTED_NETWORKS: Record<string, string> = {
    '0x1': 'Ethereum Mainnet',
    '0x5': 'Goerli Testnet',
    '0xaa36a7': 'Sepolia Testnet',
    '0x89': 'Polygon Mainnet',
    '0x13881': 'Mumbai Testnet',
    '0x38': 'BSC Mainnet',
    '0x61': 'BSC Testnet',
    '0x2105': 'Base Mainnet',
    '0x14a33': 'Base Sepolia Testnet',
};
/* eslint-enable @typescript-eslint/naming-convention */

@Injectable({ providedIn: 'root' })
export class Web3Service {
    private readonly _walletAddress$ = new BehaviorSubject<string | null>(null);
    private readonly _networkInfo$ = new BehaviorSubject<NetworkInfo | null>(null);
    private readonly _isMetaMaskInstalled$ = new BehaviorSubject<boolean>(false);
    private readonly _errorMessage$ = new BehaviorSubject<string | null>(null);
    private _provider: BrowserProvider | null = null;

    readonly walletAddress$ = this._walletAddress$.asObservable();
    readonly networkInfo$ = this._networkInfo$.asObservable();
    readonly isMetaMaskInstalled$ = this._isMetaMaskInstalled$.asObservable();
    readonly errorMessage$ = this._errorMessage$.asObservable();

    constructor(private readonly _ngZone: NgZone) {
        this._init();
    }

    private _init(): void {
        if (typeof window === 'undefined') return;

        if (window.ethereum?.isMetaMask) {
            this._isMetaMaskInstalled$.next(true);
            this._provider = new BrowserProvider(window.ethereum);
            this._setupEventListeners();
        }
    }

    private _setupEventListeners(): void {
        if (!window.ethereum?.on) return;

        window.ethereum.on('accountsChanged', (accounts: string[]) => {
            this._ngZone.run(() => {
                if (accounts.length === 0) {
                    this._walletAddress$.next(null);
                    this._errorMessage$.next('Wallet disconnected');
                } else {
                    this._walletAddress$.next(accounts[0]);
                    this._errorMessage$.next(null);
                }
            });
        });

        window.ethereum.on('chainChanged', (chainId: string) => {
            this._ngZone.run(() => this._updateNetworkInfo(chainId));
        });

        window.ethereum.on('disconnect', () => {
            this._ngZone.run(() => {
                this._walletAddress$.next(null);
                this._networkInfo$.next(null);
                this._errorMessage$.next('MetaMask disconnected');
            });
        });
    }

    private _updateNetworkInfo(chainId: string): void {
        const networkName = SUPPORTED_NETWORKS[chainId] || 'Unknown Network';
        const isSupported = chainId in SUPPORTED_NETWORKS;

        this._networkInfo$.next({ chainId, name: networkName, isSupported });

        if (!isSupported) {
            this._errorMessage$.next(
                `Unsupported network: ${networkName} (${chainId}). Please switch to a supported network.`,
            );
        } else {
            this._errorMessage$.next(null);
        }
    }

    async connectWallet(): Promise<void> {
        try {
            if (!this._isMetaMaskInstalled$.value) {
                this._errorMessage$.next('MetaMask is not installed.');
                return;
            }

            if (!this._provider) {
                this._errorMessage$.next('Provider not initialized');
                return;
            }

            const accounts = (await this._provider.send('eth_requestAccounts', [])) as string[];

            if (accounts.length > 0) {
                this._walletAddress$.next(accounts[0]);
                this._errorMessage$.next(null);

                const network = await this._provider.getNetwork();
                const chainId = '0x' + network.chainId.toString(16);
                this._updateNetworkInfo(chainId);
            }
        } catch (err) {
            const error = err as MetaMaskError;

            if (error.code === 4001) {
                this._errorMessage$.next('Connection rejected');
            } else if (error.code === -32002) {
                this._errorMessage$.next('Connection pending. Check MetaMask.');
            } else {
                this._errorMessage$.next(`Failed to connect: ${error.message || 'Unknown error'}`);
            }

            console.error('Error connecting wallet:', error);
        }
    }

    disconnectWallet(): void {
        this._walletAddress$.next(null);
        this._networkInfo$.next(null);
        this._errorMessage$.next(null);
    }

    shortenAddress(address: string | null): string {
        if (!address) return '';
        return `${address.slice(0, 6)}...${address.slice(-4)}`;
    }
}
